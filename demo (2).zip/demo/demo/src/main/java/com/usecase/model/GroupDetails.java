package com.usecase.model;

import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;

	@Entity(name = "Groupdetails")
	public class GroupDetails {

	   @Id
	   @GeneratedValue(strategy = GenerationType.IDENTITY)
	   private Long id;
	//	@Column(name = "groupname")
	   private String groupName;
		//@Column(name = "groupaddress")
	   private String groupAddress;
		//@Column(name = "groupadminname")
	   private String groupAdminName;
		//@Column(name = "groupadmincontact")
	   private String groupAdminContact;
		//@Column(name = "groupsize")
	   private String groupSize;
		//@Column(name = "groupstartdate")
	   private Date groupStartDate;
	   
   @OneToMany(cascade=CascadeType.ALL)
	   @JoinColumn(name="Group_ID")
	   private Set<BenefitDetails> group;
	   
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroupAddress() {
		return groupAddress;
	}
	public void setGroupAddress(String groupAddress) {
		this.groupAddress = groupAddress;
	}
	public String getGroupAdminName() {
		return groupAdminName;
	}
	public void setGroupAdminName(String groupAdminName) {
		this.groupAdminName = groupAdminName;
	}
	public String getGroupAdminContact() {
		return groupAdminContact;
	}
	public void setGroupAdminContact(String groupAdminContact) {
		this.groupAdminContact = groupAdminContact;
	}
	public String getGroupSize() {
		return groupSize;
	}
	public void setGroupSize(String groupSize) {
		this.groupSize = groupSize;
	}
	
	public Date getGroupStartDate() {
		return groupStartDate;
	}
	public void setGroupStartDate(Date groupStartDate) {
		this.groupStartDate = groupStartDate;
	}
	public Set<BenefitDetails> getGroup() {
		return group;
	}
	public void setGroup(Set<BenefitDetails> group) {
		this.group = group;
	}
	
	@Override
	public String toString() {
		return "GroupDetails [id=" + id + ", groupName=" + groupName
				+ ", groupAddress=" + groupAddress + ", groupAdminName="
				+ groupAdminName + ", groupAdminContact=" + groupAdminContact
				+ ", groupSize=" + groupSize + ", groupStartDate="
				+ groupStartDate + "]";
	}
	   
	   
	
}
