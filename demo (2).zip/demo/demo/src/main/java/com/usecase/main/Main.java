package com.usecase.main;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.bind.annotation.CrossOrigin;

import com.usecase.service.BenefitDetailsService;
import com.usecase.service.BenefitDetailsServiceImpl;

//import com.usecase.service.BenefitDetailsServiceImpl;

import javax.annotation.Resource;

import org.springframework.boot.CommandLineRunner;
//import org.springframework.web.bind.annotation.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@CrossOrigin("${origem-permitida}")
@SpringBootApplication(scanBasePackages={
		"com.usecase.service", "BookController","com.usecase.config","com.usecase.dao","com.usecase.nodel"})
//@ComponentScan({ "com.usecase.service", "BookController","com.usecase.config","com.usecase.dao","com.usecase.nodel" })

public class Main implements CommandLineRunner {

	@Resource
	BenefitDetailsService storageService;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //SpringApplication application = new SpringApplication(MyApplication.class);
		SpringApplication.run(Main.class, args);
		
	}

	@Override
	public void run(String... arg) throws Exception {
	 
	} 

	
}
