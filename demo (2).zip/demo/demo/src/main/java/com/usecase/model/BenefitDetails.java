package com.usecase.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
@Entity(name = "Benefitdetails")
public class BenefitDetails {

	   @Id
	   @GeneratedValue(strategy = GenerationType.IDENTITY)
	   private Long id;
		//@Column(name = "name")
	   private String benefitName;
		//@Column(name = "name")
	   private Date benefitStartDate;
	//	@Column(name = "endname")
	   private Date benefitEndDate;
		//@Column(name = "startname")
	   private boolean benefitcoveredisMedical;
		//@Column(name = "cbname")
	   private boolean benefitcoveredisDental;
		//@Column(name = "dfgname")
	   private boolean benefitcoveredisVision;
		//@Column(name = "fdgname")
	   private boolean benefitcoveredisPharmacy;
	//	@Column(name = "fgdname")
	   private Integer benefitcopay;
	//	@Column(name = gh"name")
	   private Integer benefitDeductible;
	//	@Column(name = "dfghname")
	   private Integer benefitcoInsurance;
	  
	 @ManyToOne//(fetch = FetchType.LAZY)
//	    
//
//	  private GroupDetails group_id;

	  
	public boolean isBenefitcoveredisMedical() {
		return benefitcoveredisMedical;
	}

	public void setBenefitcoveredisMedical(boolean benefitcoveredisMedical) {
		this.benefitcoveredisMedical = benefitcoveredisMedical;
	}

	public boolean isBenefitcoveredisDental() {
		return benefitcoveredisDental;
	}

	public void setBenefitcoveredisDental(boolean benefitcoveredisDental) {
		this.benefitcoveredisDental = benefitcoveredisDental;
	}

	public boolean isBenefitcoveredisVision() {
		return benefitcoveredisVision;
	}

	public void setBenefitcoveredisVision(boolean benefitcoveredisVision) {
		this.benefitcoveredisVision = benefitcoveredisVision;
	}

	public boolean isBenefitcoveredisPharmacy() {
		return benefitcoveredisPharmacy;
	}

	public void setBenefitcoveredisPharmacy(boolean benefitcoveredisPharmacy) {
		this.benefitcoveredisPharmacy = benefitcoveredisPharmacy;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getBenefitName() {
		return benefitName;
	}

	public void setBenefitName(String benefitName) {
		this.benefitName = benefitName;
	}

	public Date getBenefitStartDate() {
		return benefitStartDate;
	}

	public void setBenefitStartDate(Date benefitStartDate) {
		this.benefitStartDate = benefitStartDate;
	}

	public Date getBenefitEndDate() {
		return benefitEndDate;
	}

	public void setBenefitEndDate(Date benefitEndDate) {
		this.benefitEndDate = benefitEndDate;
	}

	public Integer getBenefitcopay() {
		return benefitcopay;
	}

	public void setBenefitcopay(Integer benefitcopay) {
		this.benefitcopay = benefitcopay;
	}

	public Integer getBenefitDeductible() {
		return benefitDeductible;
	}

	public void setBenefitDeductible(Integer benefitDeductible) {
		this.benefitDeductible = benefitDeductible;
	}

	public Integer getBenefitcoInsurance() {
		return benefitcoInsurance;
	}

	public void setBenefitcoInsurance(Integer benefitcoInsurance) {
		this.benefitcoInsurance = benefitcoInsurance;
	}

//	public GroupDetails getGroup_id() {
//		return group_id;
//	}
//
//	public void setGroup_id(GroupDetails group_id) {
//	this.group_id = group_id;
//	}
//	
	   
}
