package com.usecase.dao;

import com.usecase.model.BenefitDetails;
import com.usecase.model.EmployeeGroup;
import com.usecase.model.GroupDetails;

public class validationDao {
	
	//BenefitDetails y[]=new BenefitDetails[z];
	public GroupDetails groupdetail(EmployeeGroup em)
	{
		GroupDetails x=null;
		x=em.getGroup();
		return x;
	}
	
	public BenefitDetails[] benefitdetail(EmployeeGroup em)
	{
		int z=em.getEmp().length;
		BenefitDetails y[]=new BenefitDetails[z];
		y=em.getEmp();
		return y;
	}
	
	
}
