package com.usecase.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.usecase.dao.BenefitDetailsDao;
import com.usecase.dao.BenefitdetailsDaoImpl;
import com.usecase.dao.GroupDetailsDao;
import com.usecase.model.BenefitDetails;
import com.usecase.model.GroupDetails;

@Service
//@Component
@Transactional(readOnly = true)
public class BenefitDetailsServiceImpl implements BenefitDetailsService {
	@Autowired
	   private BenefitdetailsDaoImpl benefitdetailsDao;
	@Transactional
	public long save(BenefitDetails benefitdetails) {
		 return benefitdetailsDao.save(benefitdetails);
	}

	   
	  /* @Override
	   public long save(BenefitDetails benefitdetails) {
	      return benefitdetailsDao.save(benefitdetails);
	   }*/
}
