package com.usecase.dao;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.usecase.model.BenefitDetails;
import com.usecase.model.GroupDetails;
@Repository

public class BenefitdetailsDaoImpl implements BenefitDetailsDao{
	
	@Autowired
	
	   private SessionFactory sessionFactory;

	public long save(BenefitDetails benefitdetails) {
		sessionFactory.getCurrentSession().save(benefitdetails);
	      return benefitdetails.getId();
	}
	
	/*@Override
	public long save(BenefitDetails benefitdetails) {
		sessionFactory.getCurrentSession().save(benefitdetails);
	      return benefitdetails.getId();
	}*/
}
