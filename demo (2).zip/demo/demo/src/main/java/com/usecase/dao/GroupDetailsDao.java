package com.usecase.dao;


import com.usecase.model.GroupDetails;

public interface GroupDetailsDao {
	 long save(GroupDetails groupdetails);
}
