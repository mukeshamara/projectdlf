package com.usecase.model;

import java.util.Arrays;

public class EmployeeGroup {

	
	private GroupDetails group;
	//private BenefitDetails benefits;
	private BenefitDetails[] emp;
	
	public GroupDetails getGroup() {
		return group;
	}
	public void setGroup(GroupDetails group) {
		this.group = group;
	}
	public BenefitDetails[] getEmp() {
		return emp;
	}
	public void setEmp(BenefitDetails[] emp) {
		this.emp = emp;
	}
	@Override
	public String toString() {
		return "EmployeeGroup [group=" + group + ", emp=" + Arrays.toString(emp) + "]";
	}
	
	
}
