//package BookController;
//import java.util.List;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//
//
//import com.usecase.model.GroupDetails;
//import com.usecase.service.GroupDetailsService;
//
//
//@CrossOrigin(origins = "*")
//@RestController
//
//public class GroupDetailsController {
//
//
//	   @Autowired
//	   private GroupDetailsService groupdetailsservice;
//
//	   /*---Add new book---*/
//	   @PostMapping("/user")
//	   public ResponseEntity<?> save(@RequestBody GroupDetails groupdetails) {
//		  System.out.println("the json value of groupdetails is :::::: "+groupdetails);
//	      long id = groupdetailsservice.save(groupdetails);
//	      return ResponseEntity.ok().body("New Group has been saved with ID:" + id);
//	   }
//}
