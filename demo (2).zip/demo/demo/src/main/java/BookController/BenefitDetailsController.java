package BookController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.usecase.dao.validationDao;
import com.usecase.model.BenefitDetails;
import com.usecase.model.EmployeeGroup;
import com.usecase.model.GroupDetails;
import com.usecase.service.BenefitDetailsService;
import com.usecase.service.BenefitDetailsServiceImpl;
import com.usecase.service.GroupDetailsService;
import com.usecase.service.GroupDetailsServiceImpl;

//@CrossOrigin(origins = "http://localhost:4200/*")

@RestController
public class BenefitDetailsController {

	

	   @Autowired
	   private BenefitDetailsServiceImpl benefitdetailsservice;
	   @Autowired
	   private GroupDetailsServiceImpl groupdetailsservice;

	   /*---Add new book---*/
//	   @PostMapping("/benefit")
//	   public ResponseEntity<?> save(@RequestBody BenefitDetails benefitdetails) {
//		  System.out.println("the json value of Benefit is :::::: "+benefitdetails);
//	      long id = benefitdetailsservice.save(benefitdetails);
//	      return ResponseEntity.ok().body("Benefit details has been saved with ID:" + id);
//	   }
	   @RequestMapping(value = "", method = RequestMethod.POST, produces = { MediaType.APPLICATION_JSON_UTF8_VALUE })
	   @PostMapping("/api")
	   public ResponseEntity<?> save(@RequestBody EmployeeGroup employeegroup) {
		   String message = "";
		  System.out.println("the json value of Benefit is :::::: "+employeegroup);
		   message = "You successfully not uploaded " ;
		   System.out.println(employeegroup);
		   validationDao dao=new validationDao();
		   GroupDetails detail=dao.groupdetail(employeegroup);
		   BenefitDetails[] details=dao.benefitdetail(employeegroup);
		   try {
		   long id1 = groupdetailsservice.save(detail);
		   long id=0;
		   if(id1>0)
		   {
			   for(int i=0;i<details.length;i++)
			   {
			   id = benefitdetailsservice.save(details[i]);
			   }
			
		   }
	      
	      return ResponseEntity.ok().body("Benefit details has been saved with ID:" + id);
		   }catch(Exception ex)
		   {
			   System.out.println("error is there");
			   return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body(message);
		   }
	   }
	   
}
