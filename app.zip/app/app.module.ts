import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import {FormsModule} from '@angular/forms';
import { GroupdetailsformComponent } from './groupdetailsform/groupdetailsform.component';
import { BenefitdetailsComponent } from './benefitdetails/benefitdetails.component';
//import { InMemoryDataService } from './in-memory-data.service';
import {RouterModule, Routes} from '@angular/router'
import { GroupservicesService } from './services/groupservices.service';
import { GroupInsertService } from './services/group-insert.service';
import { BenefitInsertService } from './services/benefit-insert.service';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http'; 

//import { GroupemployeeComponent } from './groupemployee/groupemployee.component';

const appRoutes :Routes=[
  {path:'home', component:AppComponent },
  {path:'groupdetails', component:GroupdetailsformComponent },
  {path:'benefitdetails', component:BenefitdetailsComponent}
  


  ]
  
@NgModule({
  declarations: [
    AppComponent,
    
    GroupdetailsformComponent,
    BenefitdetailsComponent
  ],
  imports: [
    BrowserModule,
     FormsModule,
    HttpModule,
     HttpClientModule,
      RouterModule.forRoot(appRoutes)
  ],
  providers: [GroupservicesService, GroupInsertService, BenefitInsertService],
  bootstrap: [AppComponent]
})
export class AppModule { }
