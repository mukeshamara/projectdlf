//class object for bebefit details
export class Benefits {
    id: number;
    benefitname: string;
    benefitstartdate: Date;
    benefitenddate: Date;
    benefitcoveredisMedical:boolean=false;
    benefitcoveredisDental:boolean=false;;
    benefitcoveredisVision:boolean=false;;
    benefitcoveredisPharmacy:boolean=false;
    benefitcopay:number;
    benefitdeductible:number;
    benefitcoinsurance:number;
    /*Both the passwords are in a single object*/
   
   

    constructor(values: Object = {}) {
        /*Constructor initialization*/
        Object.assign(this, values);
    }
}