import { Component, OnInit } from '@angular/core';
import {Benefits} from '../Benefits';
import {User} from '../user';
import {EmployeeGroup} from '../employeegroup';
import {Router} from '@angular/router';
import { GroupservicesService } from '../services/groupservices.service';
import { BenefitInsertService } from '../services/benefit-insert.service';
import { FormBuilder,FormGroup,Validators} from '@angular/forms';
import { HttpClient, HttpResponse, HttpEventType } from '@angular/common/http';

@Component({
  selector: 'app-benefitdetails',
  templateUrl: './benefitdetails.component.html',
  styleUrls: ['./benefitdetails.component.css']
})
export class BenefitdetailsComponent implements OnInit {

  benefit:Benefits;
  benefits:Benefits[];
  error:String;
  groupdetails:User;
  d=new Date();
  //total data
  complete:EmployeeGroup;
//service method is used to get value from one component to this
  constructor(public router: Router, private lService: GroupservicesService, private benefitdetails: BenefitInsertService) { 
    this.d=this.lService.userDate;
    //first page data
    this.groupdetails=this.lService.user; 

    this.benefit = new Benefits({
      benefitname: '', benefitstartdate:'' , benefitenddate: '', benefitcoveredisMedical:false,benefitcoveredisDental:false,
      benefitCoveredisVision:false,benefitcoveredisPharmacy:false,
      benefitcopay: '',benefitdeductible:'', benefitcoinsurance:''});
      this.benefits=[];
      this.complete=new EmployeeGroup({
        group:'',benefits:''
      });

  }

  ngOnInit() {
  }
// date:this.lService.userDate-->

getToday()
  {
    return this.d;
  }

  addBenefit(): void {
    // this.benefitdetails.addBenefit(this.complete)
    //   .subscribe((response) => { console.log(response); },
    //     (error) => {
    //       console.log(error);
    //     }
    //   );
  
    this.benefitdetails.addBenefit(this.complete)
     // this.benefitdetails.addBenefit(this.complete)
       .subscribe((response) => { console.log(response); },
         (error) => {
           console.log(error);
         }
       );
  //  .subscribe(event => {
  //     if (event.type === HttpEventType.UploadProgress) {
  //       //this.progress.percentage = Math.round(100 * event.loaded / event.total);
  //     } else if (event instanceof HttpResponse) {
  //       console.log('File is completely uploaded!');
  //     }
  //   });

  }
//this button will work for adding multiple benefit details
  onSubmit({ value, valid}: { value: Benefits, valid: boolean }) {

    //we are loading the values of html into local object variable
    this.benefit = value;
    //1st page data is sending to whole
    this.complete.group=this.groupdetails;
    if(this.benefit.benefitcoveredisMedical==false &&this.benefit.benefitcoveredisDental==false &&
this.benefit.benefitcoveredisVision==false &&
this.benefit.benefitcoveredisPharmacy==false)
{
this.error='You can not add the benefit details without selecting any one of the benefitcovered';

}
else
{


    this.benefits.push(this.benefit);
    console.log( this.benefit);
    console.log('valid: ' + valid);
    this.router.navigate(['benefitdetails'])
  
}
}

//after filling the benefit details we can submit
onClickMe(){
  //2nd page data in whole data
  this.complete.benefits=this.benefits;
  console.log(this.complete);
  if(this.benefits.length<1)
  {
  this.error='Please add the benefit details';
  //this is used after submitting the button we are going to the page 
  this.router.navigate(['benefitdetails'])
  }
else
{
  this.complete.benefits=this.benefits;
    this.addBenefit();
  this.router.navigate(['/'])
}


}
}
