import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BenefitdetailsComponent } from './benefitdetails.component';

describe('BenefitdetailsComponent', () => {
  let component: BenefitdetailsComponent;
  let fixture: ComponentFixture<BenefitdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BenefitdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BenefitdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
