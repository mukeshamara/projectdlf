import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupemployeeComponent } from './groupemployee.component';

describe('GroupemployeeComponent', () => {
  let component: GroupemployeeComponent;
  let fixture: ComponentFixture<GroupemployeeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupemployeeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupemployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
