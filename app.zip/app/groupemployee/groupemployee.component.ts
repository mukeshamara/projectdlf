import { Component, OnInit } from '@angular/core';
import {Benefits} from '../Benefits';
import {User} from '../user';
//import {EmployerGroup} from '../employergroup';
import {Router} from '@angular/router';
import { GroupservicesService } from '../services/groupservices.service';
import { BenefitInsertService } from '../services/benefit-insert.service';
import { FormBuilder,FormGroup,Validators} from '@angular/forms';

@Component({
  selector: 'app-groupemployee',
  templateUrl: './groupemployee.component.html',
  styleUrls: ['./groupemployee.component.css']
})
export class GroupemployeeComponent implements OnInit {
//x:Employergroup;
u:User;
b1:Array<Benefits>;
  constructor(public router: Router, private lService: GroupservicesService, private benefitdetails: BenefitInsertService) { 
    this.u=this.lService.user;
    this.b1=this.lService.b;

  }

  ngOnInit() {
  }

}
