//This is for Group details
export class User {
    
    groupname: string;
    groupaddress: string;
    groupadminname: string;
    groupadmincontact: string;
    groupsize:string;
    groupstartdate:Date;
    
    /*Both the passwords are in a single object*/
   
   
    constructor(values: Object = {}) {
        /*Constructor initialization*/
        Object.assign(this, values);
    }
}
