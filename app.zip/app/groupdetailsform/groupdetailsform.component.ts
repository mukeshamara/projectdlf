import { Component, OnInit } from '@angular/core';
import {User} from '../user';
import {Router} from '@angular/router';
import { GroupservicesService } from '../services/groupservices.service';
import { GroupInsertService } from '../services/group-insert.service';

@Component({
  selector: 'app-groupdetailsform',
  templateUrl: './groupdetailsform.component.html',
  styleUrls: ['./groupdetailsform.component.css']
})
export class GroupdetailsformComponent implements OnInit {

  user: User;

  groupsize: any[];
  
//In the constructor we are using a service to send data from one child to other child
  constructor(public router: Router, private serv: GroupservicesService, private group: GroupInsertService) {
      //this is the dropdown menu details of how many people for a group
      this.groupsize = ['below 50', '50-100', '100-1000','1000-10000','above 10000'];
     
      this.user = new User({
          
          groupname: '', groupaddress:'' , groupadminname: '',groupadmincontact:'',
          groupsize: this.groupsize[0],groupstartdate:''});
         
  }

  ngOnInit() {
  }

  // addUser(): void {
  //   this.group.addUser(this.user)
  //     .subscribe((response) => { console.log(response); },
  //       (error) => {
  //         console.log(error);
          
  //       }
  //     );
  // }

  
  //This function will be worked when after filling all the details in the html page 
    onFormSubmit({ value, valid}: { value: User, valid: boolean }) {
        //The values entered in the html page will be loaded into local variable
        this.user = value;
      this.serv.userDate = this.user.groupstartdate;
      this.serv.user=this.user;
      //  this.addUser();
        console.log( this.user);
        console.log('valid: ' + valid);
        this.router.navigate(['benefitdetails'])
        
    }

}
