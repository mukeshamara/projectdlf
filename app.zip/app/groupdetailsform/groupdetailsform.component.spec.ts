import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GroupdetailsformComponent } from './groupdetailsform.component';

describe('GroupdetailsformComponent', () => {
  let component: GroupdetailsformComponent;
  let fixture: ComponentFixture<GroupdetailsformComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GroupdetailsformComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GroupdetailsformComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
