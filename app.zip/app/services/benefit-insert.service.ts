import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { HttpClient } from '@angular/common/http';
import { Benefits } from '../Benefits';
import { EmployeeGroup } from '../Employeegroup';

//To send the benefit details into database 
@Injectable({
  providedIn: 'root'
})
export class BenefitInsertService {
b:any[];
  constructor(private _httpService: Http,private http:HttpClient) { }
  addBenefit(complete : EmployeeGroup) {
   // this.b.push(benefit);
    let body = JSON.parse(JSON.stringify(complete));
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });
    if (complete.id) {
      return this.http.put("http://localhost:8080/demo/benefit" + complete.id, complete);
    } else {
      return this.http.post("http://localhost:8080/demo/benefit", complete);
    }
  }
}
