import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class GroupservicesService {
 userDate:Date;
 user:User;
 b:any[];
  constructor() {
    
   }

   public setuserDate(val:Date):void{
     this.userDate=val;
   }

   public getuserDate():Date{
     return this.userDate;
   }
}
