import { TestBed } from '@angular/core/testing';

import { BenefitInsertService } from './benefit-insert.service';

describe('BenefitInsertService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BenefitInsertService = TestBed.get(BenefitInsertService);
    expect(service).toBeTruthy();
  });
});
