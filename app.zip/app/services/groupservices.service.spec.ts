import { TestBed } from '@angular/core/testing';

import { GroupservicesService } from './groupservices.service';
import {HttpClient} from '@angular/common/http';

describe('GroupservicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GroupservicesService = TestBed.get(GroupservicesService);
    expect(service).toBeTruthy();
  });
});
