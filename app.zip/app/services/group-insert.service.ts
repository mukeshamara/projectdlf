import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';

import { User } from '../user';

@Injectable({
  providedIn: 'root'
})
export class GroupInsertService {

  constructor(private _httpService: Http) { }
  // addUser(user: User) {
  //   let body = JSON.parse(JSON.stringify(user));
  //   let headers = new Headers({ 'Content-Type': 'application/json' });
  //   let options = new RequestOptions({ headers: headers });
  //   if (user.id) {
  //     return this._httpService.put("http://localhost:8080/spring-mvc-restfull-crud-example/user/" + user.id, user, options);
  //   } else {
  //     return this._httpService.post("http://localhost:8080/spring-mvc-restfull-crud-example/user", user, options);
  //   }
  // }
}
