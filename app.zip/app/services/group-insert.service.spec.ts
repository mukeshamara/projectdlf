import { TestBed } from '@angular/core/testing';

import { GroupInsertService } from './group-insert.service';

describe('GroupInsertService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: GroupInsertService = TestBed.get(GroupInsertService);
    expect(service).toBeTruthy();
  });
});
