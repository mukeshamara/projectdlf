import { Benefits } from './Benefits';
import { User } from './user';

export class EmployeeGroup
{
    id:number;
    group:User;
    benefits:Benefits[];

 constructor(values: Object = {}) {
        /*Constructor initialization*/
        Object.assign(this, values);
    }
}