package com.usecase.dao;

import com.usecase.model.BenefitDetails;
import com.usecase.model.GroupDetails;

public interface BenefitDetailsDao {
	 long save(BenefitDetails benefitdetails);
}
