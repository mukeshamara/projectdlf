package com.usecase.service;
import java.util.List;

import com.usecase.model.GroupDetails;


public interface GroupDetailsService {
	long save(GroupDetails groupdetails);
}
