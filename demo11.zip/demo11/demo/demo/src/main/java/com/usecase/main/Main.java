package com.usecase.main;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.usecase.model.BenefitDetails;
import com.usecase.model.GroupDetails;
import com.usecase.service.BenefitDetailsService;
import com.usecase.service.BenefitDetailsServiceImpl;
import com.usecase.service.GroupDetailsServiceImpl;

//import com.usecase.service.BenefitDetailsServiceImpl;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
//import org.springframework.web.bind.annotation.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;

@Configuration
@EnableWebMvc
///@EnableAsync
@CrossOrigin("${origem-permitida}")

@SpringBootApplication(scanBasePackages={
		"com.usecase.service", "BookController","com.usecase.config","com.usecase.dao","com.usecase.nodel"})
//@ComponentScan
//@ComponentScan({ "com.usecase.service", "BookController","com.usecase.config","com.usecase.dao","com.usecase.nodel" })

public class Main implements CommandLineRunner {

	
	 @Autowired
	   BenefitDetailsServiceImpl benefitdetailsservice;
	   @Autowired
	   GroupDetailsServiceImpl groupdetailsservice;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //SpringApplication application = new SpringApplication(MyApplication.class);
		SpringApplication.run(Main.class, args);
		
		
		
	}

	@Override
	public void run(String... arg) throws Exception {
		 GroupDetails detail=new GroupDetails();
		   detail.setGroupAddress("sddfgf");
		   detail.setGroupAdminName("dwdg");
		   System.out.println(detail);
		   BenefitDetails details=new BenefitDetails();
	   details.setBenefitName("asdgdf");
		   details.setBenefitcopay(121);
		   details.setGroup(detail);
//		   details[1].setBenefitName("dswdf");
//		   details[1].setBenefitDeductible(233);
		   try {
		   long id1 = groupdetailsservice.save(detail);
		   System.out.println(id1);
		   long id=0;
		   if(id1>0)
		   {
//			   for(int i=0;i<details.length;i++)
//			   {
			   id = benefitdetailsservice.save(details);
//			   }
			System.out.println(id1);
		   }
	      
	   //   return ResponseEntity.ok().body("Benefit details has been saved with ID:" + id);
		   }catch(Exception ex)
		   {
			   System.out.println("error is there");
			  // return ResponseEntity.status(HttpStatus.EXPECTATION_FAILED).body("it is");
		   }
	} 

	
}
