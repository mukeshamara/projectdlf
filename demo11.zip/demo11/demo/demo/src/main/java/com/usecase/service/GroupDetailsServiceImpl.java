package com.usecase.service;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



import com.usecase.dao.GroupDetailsDao;
import com.usecase.model.GroupDetails;


@Service
//@Component
@Transactional(readOnly = true)

public class GroupDetailsServiceImpl {
	 @Autowired
	   private GroupDetailsDao groupdetailsDao;

	 @Transactional
	public long save(GroupDetails groupdetails) {
		  return groupdetailsDao.save(groupdetails);
	}

	  
	   /*@Override
	   public long save(GroupDetails groupdetails) {
	      return groupdetailsDao.save(groupdetails);
	   }*/
}
