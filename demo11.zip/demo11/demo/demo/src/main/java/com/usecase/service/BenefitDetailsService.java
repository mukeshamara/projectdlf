package com.usecase.service;

import com.usecase.model.BenefitDetails;
import com.usecase.model.GroupDetails;

public interface BenefitDetailsService {
	long save(BenefitDetails benefitdetails);
}
